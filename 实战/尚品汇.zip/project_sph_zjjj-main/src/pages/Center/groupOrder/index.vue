<template>
  <div>团购订单</div>
</template>

<script>
export default {
  name: "GroupOrder",
};
</script>

<style>
</style>